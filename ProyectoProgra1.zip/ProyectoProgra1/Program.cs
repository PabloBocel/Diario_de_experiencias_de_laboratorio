﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ProyectoProgra1
{
    internal class Program
    {
        static void Main(string[] args) // Pablo Andrés Bocel Morales 1109623 y Christopher Javier Yuman Valdez 1160223
        {
            Console.WriteLine("\tBienvienido/a al sistema de facturación de TIENDAS MÁS" + "\n-----------------------comprando con bendición ve-----------------------");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("                                                          ___");
            Console.WriteLine("                                                       .~))>>");
            Console.WriteLine("                                                      .~)>>");
            Console.WriteLine("                                                    .~))))>>>");
            Console.WriteLine("                                                  .~))>>             ___");
            Console.WriteLine("                                                .~))>>)))>>      .-~))>>  ");
            Console.WriteLine("                                              .~)))))>>       .-~))>>)>");
            Console.WriteLine("                                            .~)))>>))))>>  .-~)>>)>");
            Console.WriteLine("                        )                 .~))>>))))>>  .-~)))))>>)>");
            Console.WriteLine("                     ( )@@*)             //)>))))))  .-~))))>>)>");
            Console.WriteLine("                   ).@(@@               //))>>))) .-~))>>)))))>>)>");
            Console.WriteLine("                 (( @.@).              //))))) .-~)>>)))))>>)>");
            Console.WriteLine("               ))  )@@*.@@ )          //)>))) //))))))>>))))>>)>");
            Console.WriteLine("            ((  ((@@@.@@             |/))))) //)))))>>)))>>)>");
            Console.WriteLine("           )) @@*. )@@ )   (ll_(ll-llb  |))>)) //)))>>)))))))>>)>");
            Console.WriteLine("         (( @@@(.@(@ .    _/`-`  ~|b |>))) //)>>)))))))>>)>");
            Console.WriteLine("          )* @@@ )@*     (@) (@)  /lb|))) //))))))>>))))>>");
            Console.WriteLine("        (( @. )@( @ .   _/       /  lb)) //))>>)))))>>>_._");
            Console.WriteLine("         )@@ (@@*)@@.  (6,   6) / ^  lb)//))))))>>)))>>   ~~-.");
            Console.WriteLine("      ( @jgs@@. @@@.*@_ ~^~^~, /ll  ^  llb/)>>))))>>      _.     `,");
            Console.WriteLine("       ((@@ @@@*.(@@ .   ll^^^/' (  ^   llb)))>>        .'         `,");
            Console.WriteLine("        ((@@).*@@ )@ )    `-'   ((   ^  ~)_          /             `,");
            Console.WriteLine("          (@@. (@@ ).           (((   ^    `ll        |               `.");
            Console.WriteLine("            (*.@*              / ((((        ll        ll      .         `.");
            Console.WriteLine("                              /   (((((  ll    ll    _.-~ll     Y,         ;");
            Console.WriteLine("                             /   / (((((( ll    ll.-~   _.`l  _.-~`,       ;");
            Console.WriteLine("                            /   /   `(((((()    )    (((((~      `,     ;");
            Console.WriteLine("                          _/  _/      `l'l'l /   /'                  ;     ;");
            Console.WriteLine("                      _.-~_.-~           /  /'                _.-~   _.'");
            Console.WriteLine("                    ((((~~              / /'              _.-~ __.--~");
            Console.WriteLine("                                       ((((          __.-~ _.-~");
            Console.WriteLine("                                                   .'   .~~");
            Console.WriteLine("                                                   :    ,'");
            Console.WriteLine("                                                   ~~~~~");
            Console.ForegroundColor = ConsoleColor.White; //nos puede dar puntos extra por creatividad? Por favor :)
            Console.WriteLine("Presione enter para continuar");

            Console.ReadKey();
            string menu = "";
            int numerofactura = 0;
            int cantidad1 = 0, cantidad2 = 0, cantidad3 = 0, cantidad4 = 0, cantidad5 = 0;
            int cantidadpuntos = 0;
            int cantidadproductos = 0;
            int sumtotal = 0;

            while (!menu.Equals("3"))
            {
                try // lo que se hace con este try catch es prevenir los errores que el usuario pueda cometer al momento de ingresar algún dato inválido como por ejemplo colocar palabras en una variable tipo int 
                {
                    Console.Clear();
                    Console.WriteLine("--------------------------Sistema de TIENDAS MÁS--------------------------\n");
                    Console.WriteLine("Por favor escoge una opción\n");
                    Console.WriteLine("1.Facturación" + "\n2.Reportes de facturación" + "\n3.Salir\n");
                    int opcion = 0;
                    opcion = Convert.ToInt32(Console.ReadLine());


                    switch (opcion)
                    {

                        case 1: // el caso 1 es el que corresponde al proceso de facturación 
                            char respuesta;
                            do
                            {
                                Console.Clear();

                                double resultado = 0;
                                double total = 0;
                                int puntos = 0;
                                int nombre1 = 0;
                                string nombre;
                                cantidad1 = 0;
                                cantidad2 = 0;
                                cantidad3 = 0;
                                cantidad4 = 0;
                                Console.WriteLine("Usted ha escogido la opción de facturación\n");
                                bool canConvert = false;
                                do
                                {
                                    Console.Clear();
                                    Console.WriteLine("Usted ha escogido la opción de facturación\n");
                                    Console.WriteLine("Ingrese su nombre");

                                    nombre = (Console.ReadLine());
                                    canConvert = int.TryParse(nombre, out nombre1);
                                    if (canConvert == true)
                                    {
                                        Console.WriteLine("Lo que ingreso son solo numeros, ingrese un texto");
                                        Console.ReadKey();
                                    }
                                }
                                while (canConvert == true);
                                int nit = 0;
                                Regreso:
                                Console.WriteLine("Ingrese su nit"); // en esta parte se solicitan los datos y se muestra en pantalla los productos disponiblers en la tienda con sus precios
                                try
                                {
                                   nit = Convert.ToInt32(Console.ReadLine());
                                }
                                catch
                                {
                                    Console.WriteLine("Ingrese solo numeros");
                                    goto Regreso;
                                }
                                
                                Console.WriteLine("Ingrese su correo");
                                string correo = (Console.ReadLine());
                                Console.WriteLine("-----------------------------------");
                                Console.WriteLine("Código |     Producto    |   Precio");
                                Console.WriteLine("-----------------------------------");
                                Console.WriteLine(" 001   | Libra de azúcar |  Q.10.80");
                                Console.WriteLine(" 002   | Libra de arroz  |  Q.3.80 ");
                                Console.WriteLine(" 003   |  Galleta GAMA   |  Q.1.10 ");
                                Console.WriteLine(" 004   |   Coca Cola     |  Q.17.00");
                                Console.WriteLine(" 005   |  Libra de Café  |  Q.50.00");
                                Console.WriteLine("-----------------------------------");

                                do // este do while sirve para que el usuario pueda volver a escoger otro producto en su compra
                                {
                                    Console.WriteLine("Ingrese el codigo del producto");
                                    int codigo = Convert.ToInt32(Console.ReadLine());


                                    if (codigo == 001) // estos if son las cantidades del producto escogido que comprará el usuario y una variable sumará el precio del producto con la cantidad y la otra hará una suma de los productos vendidos para mostrarlo posteriormente
                                    {
                                        Console.WriteLine("Ingrese la cantidad del producto");
                                        codigo1:
                                        try // todos estos try catch funcionan para que cuando el usuario escriba letras envez de numeros el error no lo saque del proceso de facturacion
                                        {
                                            int cantidad = Convert.ToInt32(Console.ReadLine());
                                            if (cantidad > 0)
                                            {
                                                resultado = 10.80 * cantidad;
                                                resultado = total + resultado;
                                                total = resultado;
                                                cantidad1 = cantidad1 + cantidad;
                                                sumtotal = cantidad1 + sumtotal;
                                            }
                                            else
                                            {
                                                Console.WriteLine("Ingrese una cantidad mayor a 0");
                                            }
                                        }
                                        catch
                                        {
                                            Console.WriteLine("Ingrese la cantidad en números");
                                            goto codigo1;
                                        }

                                    }
                                    else if (codigo == 002)
                                    {
                                        Console.WriteLine("Ingrese la cantidad del producto");
                                        codigo2:
                                        try
                                        {
                                            int cantidad = Convert.ToInt32(Console.ReadLine());

                                            if (cantidad > 0)
                                            {
                                                resultado = 3.80 * cantidad;
                                                resultado = total + resultado;
                                                total = resultado;
                                                cantidad2 = cantidad2 + cantidad;
                                                sumtotal = cantidad2 + sumtotal;

                                            }
                                            else
                                            {
                                                Console.WriteLine("Ingrese una cantidad mayor a 0");
                                            }
                                        }
                                        catch
                                        {
                                            Console.WriteLine("Ingrese la cantidad en números");
                                            goto codigo2;
                                        }
                                    }
                                    else if (codigo == 003)
                                    {
                                        Console.WriteLine("Ingrese la cantidad del producto");
                                        codigo3:
                                        try
                                        {
                                            int cantidad = Convert.ToInt32(Console.ReadLine());

                                            if (cantidad > 0)
                                            {
                                                resultado = 1.10 * cantidad;
                                                resultado = total + resultado;
                                                total = resultado;
                                                cantidad3 = cantidad3 + cantidad;
                                                sumtotal = cantidad3 + sumtotal;

                                            }
                                            else
                                            {
                                                Console.WriteLine("Ingrese una cantidad mayor a 0");
                                            }
                                        }
                                        catch
                                        {
                                            Console.WriteLine("Ingrese la cantidad en números");
                                            goto codigo3;
                                        }
                                    }
                                    else if (codigo == 004)
                                    {
                                        Console.WriteLine("Ingrese la cantidad del producto");
                                        codigo4:
                                        try
                                        {
                                            int cantidad = Convert.ToInt32(Console.ReadLine());

                                            if (cantidad > 0)
                                            {
                                                resultado = 17.00 * cantidad;
                                                resultado = total + resultado;
                                                total = resultado;
                                                cantidad4 = cantidad4 + cantidad;
                                                sumtotal = cantidad4 + sumtotal;

                                            }
                                            else
                                            {
                                                Console.WriteLine("Ingrese una cantidad mayor a 0");
                                            }
                                        }
                                        catch
                                        {
                                            Console.WriteLine("Ingrese la cantidad en números");
                                            goto codigo4;
                                        }
                                    }
                                    else if (codigo == 005)
                                    {
                                        Console.WriteLine("Ingrese la cantidad del producto");
                                        codigo5:
                                        try
                                        {
                                            int cantidad = Convert.ToInt32(Console.ReadLine());

                                            if (cantidad > 0)
                                            {
                                                resultado = 50.00 * cantidad;
                                                resultado = total + resultado;
                                                total = resultado;
                                                cantidad5 = cantidad5 + cantidad;
                                                sumtotal = cantidad5 + sumtotal;

                                            }
                                            else
                                            {
                                                Console.WriteLine("Ingrese una cantidad mayor a 0");
                                            }
                                        }
                                        catch
                                        {
                                            Console.WriteLine("Ingrese la cantidad en números");
                                            goto codigo5;
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Ingrese un codigo correcto");
                                    }
                                    Console.WriteLine("Desea ingresar otro producto? s=si, n=no");
                                    ant1:
                                    try
                                    {
                                        respuesta = Convert.ToChar(Console.ReadLine());
                                    }
                                    catch 
                                    {
                                        Console.WriteLine("Ingrese solo 's' para si o 'n' para no");
                                        goto ant1;
                                    }

                                } while (respuesta == 's');

                                string pago;
                                do // en este do while se pregunta el método de pago con el cual se realizará la compra
                                {


                                    Console.WriteLine("Ingrese su metodo de pago (Tarjeta de credito o debito, Efectivo)");
                                    pago = (Console.ReadLine());
                                    if (pago.ToLower() == "tarjeta de credito") //estos if sirven para contar los puntos que obtendrá el ususario por sus comprar al pagar con alguna tarjeta (debito o credito)
                                    {
                                        if (total >= 10 && total <= 50)
                                        {
                                            puntos = 1 * ((int)total / 10);

                                        }
                                        else if (total > 50 && total <= 100)
                                        {
                                            puntos = 2;
                                        }
                                        else if (total > 100)
                                        {
                                            puntos = 3;

                                        }
                                    }
                                    else if (pago.ToLower() == "tarjeta de debito")
                                    {
                                        if (total >= 10 && total <= 50)
                                        {
                                            puntos = 1 * ((int)total / 10);
                                        }
                                        else if (total > 50 && total <= 100)
                                        {
                                            puntos = 2;
                                        }
                                        else if (total > 100)
                                        {
                                            puntos = 3;
                                        }
                                    }
                                    else if (pago.ToLower() == "efectivo")
                                    {

                                    }
                                    else
                                    {

                                        Console.WriteLine("Ingrese un metodo de pago correcto");
                                        

                                    }
                                } while (pago.ToLower() != "efectivo" && pago.ToLower() != "tarjeta de debito" && pago.ToLower() != "tarjeta de credito");
                                cantidadpuntos = cantidadpuntos + puntos;
                                numerofactura++;
                                Console.Clear();
                                Console.ForegroundColor = ConsoleColor.DarkYellow; // esta es la parte en la que se imprime la factura en otro color, el cual es amarillo, con todos los datos obtenidos del ususario
                                Console.WriteLine("\t\r--------------------------TIENDAS MAS -URL- NIT: 5776217-7---------------------------\n");
                                Console.WriteLine("Fecha y hora de la factura: " + DateTime.Now.ToString());
                                Console.WriteLine("Numero de factura: " + numerofactura);
                                Console.WriteLine("Nombre del cliente: " + nombre);
                                Console.WriteLine("NIT del cliente:" + nit);
                                Console.WriteLine("Correo del cliente: "+correo);
                                Console.WriteLine("El método de pago es: "+ pago.ToLower());
                                Console.WriteLine("\n\t\r--------------------------Listado de productos comprados-----------------------------\n");
                                if (cantidad1 > 0) //estos if son los que escriben la cantidad del producto y su precio que solicitó el usuario
                                {
                                    Console.WriteLine("Libra de Azúcar Cantidad: " + cantidad1 + " Precio Unitario 10.80" + " Precio total por el producto: " + cantidad1 * 10.80);

                                }
                                if (cantidad2 > 0)
                                {
                                    Console.WriteLine("Libra de Arroz  Cantidad: " + cantidad2 + " Precio Unitario 3.80" + " Precio total por el producto: " + cantidad2 * 3.80);
                                }
                                if (cantidad3 > 0)
                                {
                                    Console.WriteLine("Galleta GAMA  Cantidad: " + cantidad3 + " Precio Unitario 1.10" + " Precio total por el producto: " + cantidad3 * 1.10);
                                }
                                if (cantidad4 > 0)
                                {
                                    Console.WriteLine("Coca Cola  Cantidad: " + cantidad4 + " Precio Unitario 17.00" + " Precio total por el producto: " + cantidad4 * 17.00);
                                }
                                if (cantidad5 > 0)
                                {
                                    Console.WriteLine("Libra de Café   Cantidad: " + cantidad5 + " Precio Unitario 50.00" + " Precio total por el producto: " + cantidad5 * 50.00);
                                }
                                Console.WriteLine("\n                                                          Total de la factura Q." + total); // acá se muestran el precio final y los puntos obtenidos
                                Console.WriteLine("                                                            El total de puntos es: " + puntos);


                                Console.ForegroundColor = ConsoleColor.White;
                                Console.WriteLine("\nDesea realizar otra factura? s=si, n=no"); //se pregunta si se desea emitir otra nueva factura 
                                ant2:
                                try
                                {
                                    Console.ForegroundColor = ConsoleColor.White;
                                    respuesta = Convert.ToChar(Console.ReadLine());
                                }
                                catch
                                {
                                    Console.WriteLine("Ingrese solo 's' para si o 'n' para no");
                                    goto ant2;
                                }
                                
                            }
                            while (respuesta == 's');
                            

                            Console.ReadKey();
                            Console.Clear();
                            break;
                        case 2: // este case 2 corresponde a los reportes de facturación
                            Console.Clear();
                            Console.WriteLine("Usted ha escogido la opción de reportes de facturación\n");

                            Console.WriteLine("Total de facturas: " + numerofactura); // acá se muestran todos los datos obtenidos del caso 1 
                            cantidadproductos = cantidad1 + cantidad2 + cantidad3 + cantidad4 + cantidad5;
                            Console.WriteLine("Total de productos vendidos: " + sumtotal);
                            Console.WriteLine("Total de puntos generados: " + cantidadpuntos);
                            Console.ReadKey();
                            Console.Clear();
                            break;
                        case 3: // este case corresponde a la opción de salir
                            menu = "3";
                            Console.Clear();
                            break;
                        default:
                            Console.WriteLine("Escoge un número que esté en las opciones");
                            Console.ReadKey();
                            Console.Clear();

                            break;
                    } 
            }
                catch
            {
                Console.WriteLine("Dato no válido");
                Console.ReadKey();
                Console.Clear();
            }
        }
            Console.ReadKey();
        }
    }

}
