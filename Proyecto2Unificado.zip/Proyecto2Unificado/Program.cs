﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto2Unificado
{
    internal class ProyectoProgra2
    {
        static int CalcularEdad(DateTime fechaNacimiento)
        {
            int edad = DateTime.Today.Year - fechaNacimiento.Year;

            if (DateTime.Today.Month < fechaNacimiento.Month || (DateTime.Today.Month == fechaNacimiento.Month && DateTime.Today.Day < fechaNacimiento.Day))
            {
                edad--;
            }

            return edad;
        }
        static bool expiracion(int expMonth, int expYear)
        {
            DateTime now = DateTime.Now; // Fecha actual
            if (now.Year > expYear)
            { // Si el año actual es mayor al año de expiración, la tarjeta ha expirado
                return true;
            }
            else if (now.Year == expYear && now.Month > expMonth)
            { // Si estamos en el mismo año de expiración pero el mes actual es mayor, la tarjeta ha expirado
                return true;
            }
            else
            { // La tarjeta aún no ha expirado
                return false;
            }
        }
        public string[] MaquinaCasino()
        {
            Random r = new Random();
            string[] maquina = new string[6];
            maquina[0] = "♣"; //trebol
            maquina[1] = "♦"; //diamante
            maquina[2] = "☺"; //Carita feliz
            maquina[3] = "☼"; // Sol
            maquina[4] = "■"; //casa
            maquina[5] = "°"; //bomba
            string[] resultado = new string[4];

            for (int i = 0; i < 4; i++)
            {
                resultado[i] = maquina[r.Next(0, 6)];

            }
            return resultado;
        }
        public double Probabilidades(double monto, string[] datos)
        {
            double sum1 = 0;
            double sum2 = 0;
            double sum3 = 0;
            double sum4 = 0;
            double sumtotal = 0;
            if (datos[0] == "♣" || datos[1] == "♣" || datos[2] == "♣" || datos[3] == "♣")
            {
                for (int i = 0; i < 4; i++)
                {
                    if (datos[i] == "♣")
                    {
                        sum1 += monto * 2; //por cada vez que aparezca se duplica lo ganado
                    }
                }
            }
               
            if (datos[0] == datos[1] && datos[0] == datos[2] && datos[0] == datos[3] && datos[0] == "♦") //si el icono del diamante se repite cuatro veces se multiplica por 10
            {
                sum2 += monto * 10;
            }
            if (datos[0] == "☺" || datos[1] == "☺" || datos[2] == "☺" || datos[3] == "☺")
            {
                for (int j = 0; j < 4; j++) //revisa cuantas caritas hay en el vector y por cada una le suma la cantidad que lleva generado
                {
                    if (datos[j] == "☺")
                    {
                        sum3 += monto * 1;
                    }
                }
            }
            if (datos[0] == "☼" || datos[1] == "☼" || datos[2] == "☼" || datos[3] == "☼")
            {
                for (int l = 0; l < 4; l++) //revisa cuantos soles hay en el vector y por cada uno multiplica lo generado por 0.25 y lo suma a lo que ya lleva
                {
                    if (datos[l] == "☼")
                    {
                        sum4 += monto * 0.25;
                    }
                }
            }
            
            if (datos[0] == "°" || datos[1] == "°" || datos[2] == "°" || datos[3] == "°")
            {
                for (int a = 0; a < 4; a++) //revisa si hay alguna bomba y en caso de haber le quita todas las ganancias
                {
                    if (datos[a] == "°")
                    {
                        sumtotal = 0;
                        goto ret;
                    }
                }
            }
            sumtotal = sum1 + sum2 + sum3 + sum4;
            ret:
            return sumtotal;
        }
        public void Mostrartodo(string nombre, string identificacion, string nacionalidad, int edad, double total)
        { //Estos son todos los datos que se mostrarán al usuario cuando termie de jugar
            Console.WriteLine("Su nombre es: " + nombre);

            Console.WriteLine("Su identificación es: " + identificacion);
            Console.WriteLine("Su nacionalidad es: " + nacionalidad);
            Console.WriteLine("Su edad es: " + edad + " años");
            Console.WriteLine("La cantidad de dinero que ganó sin descontar el impuesto es: Q." + total);
            double acumulado;
            acumulado = total - (total * 0.40); //esto es el cálculo de lo ganado quitando los impuestos
            Console.WriteLine("El total de dinero que ganó quitando el impuesto del casino es:  Q." + acumulado);

        }

        static void Main(string[] args) // Pablo Andrés Bocel Morales 1109623 y Christopher Javier Yuman Valdez 1160223
        {
            Console.WriteLine("\t        Bienvienido/a a la maquina COIN MACHINE" + "\n-----------------------Apostando con bendición ve-----------------------");
            Console.ForegroundColor = ConsoleColor.Red;


            Console.WriteLine("                              .-------.");
            Console.WriteLine("                              |Jackpot|");
            Console.WriteLine("                  ____________|_______|____________");
            Console.WriteLine("                 |  __    __    ___  _____   __    |  ");
            Console.WriteLine("                 | / _1  / /   /___1/__   1 / _1   |");
            Console.WriteLine("                 | 1 1  / /   //  //  / /1 \\ 1  25|");
            Console.WriteLine("                 | _1 1/ /___/ 1_//  / /  1/_1 1 []|");
            Console.WriteLine("                 | 1__/1____/1___/   1/     1__/ []|");
            Console.WriteLine("                 |===_______===_______===_______===|");
            Console.WriteLine("                 ||*|1_     |*| _____ |*|1_     |*||");
            Console.WriteLine("                 ||*|| 1 _  |*||     ||*|| 1 _  |*||");
            Console.WriteLine("                 ||*| 1_(_) |*||*BAR*||*| 1_(_) |*||");
            Console.WriteLine("                 ||*| (_)   |*||_____||*| (_)   |*|| __");
            Console.WriteLine("                 ||*|_______|*|_______|*|_______|*||(__)");
            Console.WriteLine("                 |===_______===_______===_______===| ||");
            Console.WriteLine("                 ||*| _____ |*|1_     |*|  ___  |*|| ||");
            Console.WriteLine("                 ||*||     ||*|| 1 _  |*| |_  | |*|| ||");
            Console.WriteLine("                 ||*||*BAR*||*| 1_(_) |*|  / /  |*|| ||");
            Console.WriteLine("                 ||*||_____||*| (_)   |*| /_/   |*|| ||");
            Console.WriteLine("                 ||*|_______|*|_______|*|_______|*||_//");
            Console.WriteLine("                 |===_______===_______===_______===|_/");
            Console.WriteLine("                 ||*|  ___  |*|   |   |*| _____ |*||");
            Console.WriteLine("                 ||*| |_  | |*|  / 1  |*||     ||*||");
            Console.WriteLine("                 ||*|  / /  |*| /_ _1 |*||*BAR*||*||  ");
            Console.WriteLine("                 ||*| /_/   |*|   O   |*||_____||*||   ");
            Console.WriteLine("                 ||*|_______|*|_______|*|_______|*||");
            Console.WriteLine("                 |lc=___________________________===|");
            Console.WriteLine("                 |  /___________________________1  |");
            Console.WriteLine("                 |   |                         |   |");
            Console.WriteLine("                _|    1_______________________/    |_");
            Console.WriteLine("               (_____________________________________)");

            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("Presione enter para continuar");

            Console.ReadKey();
            
                try // lo que se hace con este try catch es prevenir los errores que el usuario pueda cometer al momento de ingresar algún dato inválido como por ejemplo colocar palabras en una variable tipo int 
                {
                    inicio:
                    Console.Clear();
                    Console.WriteLine("--------------------------CASINO COIN MACHINE--------------------------\n");

                    Console.WriteLine("Ingrese su nombre completo:");
                    string nombre = (Console.ReadLine());
                Console.WriteLine("Ingrese el numero de su tarjeta:");
                string identificacion = (Console.ReadLine());
                while (identificacion.Length != 13)
                {
                    Console.WriteLine("El número ingresado no es correcto, ingrese los 13 digitos de su tarjeta");
                    identificacion = (Console.ReadLine());
                }
                Console.WriteLine("Ingrese su nacionalidad:");
                    string nacionalidad = (Console.ReadLine());
                    Console.WriteLine("Ingrese su fecha de nacimiento de la siguiente manera : (dd/mm/yyyy)");
                    DateTime fechaNacimiento = DateTime.Parse(Console.ReadLine());

                    int edad = CalcularEdad(fechaNacimiento);

                    if (edad >= 21)
                    {
                        string respuesta;
                        Console.WriteLine("Esta seguro que desea continuar apostando? s=si, n=no");
                        respuesta = (Console.ReadLine());
                        do
                        {
                            if (respuesta.ToLower() == "s")
                            {
                                string pago;
                                do // en este do while se pregunta el método de pago con el cual se realizará la compra
                                {

                                    string respuesta2;
                                    Console.WriteLine("Ingrese su metodo de pago (Tarjeta de credito o debito, Efectivo)");
                                    pago = (Console.ReadLine());
                                    if (pago.ToLower() == "tarjeta de credito" || pago.ToLower() == "tarjeta de debito") //estos if sirven para contar los puntos que obtendrá el ususario por sus comprar al pagar con alguna tarjeta (credito)
                                    {
                                        Console.WriteLine("¿Cuanto desea apostar?");
                                        double monto = Convert.ToDouble(Console.ReadLine());
                                        double total = monto;
                                        Console.WriteLine("Ingrese el numero de su tarjeta:");
                                        string numerotarjeta = (Console.ReadLine());
                                        while (numerotarjeta.Length != 16)
                                        {
                                            Console.WriteLine("El número ingresado no es correcto, ingrese los 16 digitos de su tarjeta");
                                            numerotarjeta = (Console.ReadLine());
                                        }
                                        Console.WriteLine("Ingrese el nombre del propietario de la tarjeta:");
                                        string nombre1 = (Console.ReadLine());
                                        Console.WriteLine("Ingrese el mes de expiracion de la tarjeta:");
                                        int expMonth = Convert.ToInt32(Console.ReadLine());
                                        Console.WriteLine("Ingrese el año de expiracion de la tarjeta:");
                                        int expYear = Convert.ToInt32(Console.ReadLine());

                                        while (expiracion(expMonth, expYear))
                                        {
                                            Console.WriteLine("La tarjeta ha expirado.");
                                            Console.WriteLine("Ingrese un mes de expiracion correcto:");
                                            expMonth = Convert.ToInt32(Console.ReadLine());
                                            Console.WriteLine("Ingrese un año de expiracion correcto:");
                                            expYear = Convert.ToInt32(Console.ReadLine());
                                        }
                                        Console.Clear();
                                        Random aleatorio = new Random();
                                        
;                                       Console.WriteLine($"La probabilidad de obtener el 1000% de la apuesta es del {aleatorio.Next(1, 75)}%"); //Estas son las probabilidad de que ocurra lo solicitado
                                        Console.WriteLine($"La probabilidad de duplicar la apuesta es de {aleatorio.Next(1, 75)}%");
                                        Console.WriteLine($"La probabilidad de obtener de regreso la apuesta es de {aleatorio.Next(1, 75)}%");
                                        Console.WriteLine($"La probabilidad de perder la mitad de la apuesta es de {aleatorio.Next(1, 75)}%");
                                        Console.WriteLine($"La probabilidad de perder toda la apuesta es de {aleatorio.Next(1, 75)}%");
                                        Console.WriteLine("\nEsta seguro que desea continuar apostando? s=si, n=no");
                                    respuesta2 = (Console.ReadLine());
                                        while (respuesta2.ToLower() == "s") {
                                        
                                        regreso1:
                                            ProyectoProgra2 mostrar = new ProyectoProgra2();
                                            string[] si = mostrar.MaquinaCasino();
                                            for (int i = 0; i < 4; i++) //Esto imprime el juego
                                            {
                                                Console.Write(si[i] + "-");

                                            }
                                            
                                            total = mostrar.Probabilidades(total, si);
                                            Console.WriteLine("\nUsted se lleva Q." + total + " de dinero"); //esto imprime la cantidad de dinero generado por el juego
                                            Console.WriteLine("Desea volver a jugar? s=si, n=no");
                                            char respuesta4 = Convert.ToChar(Console.ReadLine());
                                            while (respuesta4 == 's')
                                            {
                                                goto regreso1; //regresa a seguir jugando
                                            }
                                            while (respuesta4 == 'n') //cuando la respuesta es no imprime los datos datos del usuario y sus ganancias
                                            {
                                                Console.Clear();
                                                mostrar.Mostrartodo(nombre, identificacion, nacionalidad, edad, total);
                                                respuesta4 = 'x';
                                                goto apostar;
                                            }

                                        }
                                        while (respuesta2.ToLower() == "n")
                                        {
                                            goto apostar;
                                        }
                                    }

                                    else if (pago.ToLower() == "efectivo")
                                    {
                                        Console.WriteLine("¿Cuanto desea apostar?");
                                        double monto = Convert.ToDouble(Console.ReadLine());
                                        double total1 = 0;
                                        Console.Clear();
                                        Random aleatorio = new Random();
                                        
                                        Console.WriteLine($"La probabilidad de obtener el 1000% de la apuesta es del {aleatorio.Next(1, 75)}%"); //Estas son las probabilidad de que ocurra lo solicitado
                                        Console.WriteLine($"La probabilidad de duplicar la apuesta es de {aleatorio.Next(1, 75)}%");
                                        Console.WriteLine($"La probabilidad de obtener de regreso la apuesta es de {aleatorio.Next(1, 75)}%");
                                        Console.WriteLine($"La probabilidad de perder la mitad de la apuesta es de {aleatorio.Next(1, 75)}%");
                                        Console.WriteLine($"La probabilidad de perder toda la apuesta es de {aleatorio.Next(1, 75)}%");
                                        Console.WriteLine("\nEsta seguro que desea continuar apostando? s=si, n=no");
                                        respuesta2 = (Console.ReadLine());
                                        while (respuesta2.ToLower()== "s")
                                        {
                                            regreso:
                                            ProyectoProgra2 mostrar1 = new ProyectoProgra2();
                                            string[] si = mostrar1.MaquinaCasino();
                                            for (int i = 0; i < 4; i++)
                                            {
                                                Console.Write(si[i] + "-");

                                            }
                                            
                                            total1 = mostrar1.Probabilidades(monto, si);
                                            Console.WriteLine("\nUsted se lleva Q." + total1 + " de dinero");
                                            Console.WriteLine("Desea volver a jugar? s=si, n=no");
                                            char respuesta3 = Convert.ToChar(Console.ReadLine());
                                            while (respuesta3 == 's')
                                            {
                                                monto = total1;
                                                goto regreso;
                                            }
                                            while (respuesta3 == 'n')
                                            {
                                                Console.Clear();
                                                mostrar1.Mostrartodo(nombre, identificacion, nacionalidad, edad, total1);
                                                respuesta3 = 'x'; // El x es para que no truene el programa 
                                                goto apostar;
                                            }
                                            break;
                                        }
                                        while (respuesta2.ToLower() == "n")
                                        {
                                            goto apostar;
                                        }


                                    }
                                    else
                                    {

                                        Console.WriteLine("Ingrese un metodo de pago correcto");


                                    }
                                } while (pago.ToLower() != "efectivo" && pago.ToLower() != "tarjeta de credito");

                            }
                            else if (respuesta.ToLower() == "n")
                            {
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Ingrese una respuesta correcta:");
                            }
                        } while (respuesta.ToLower() != "s" && respuesta.ToLower() != "n");

                        apostar:
                        Console.WriteLine("Desea volver a apostar? s=si, n= no");
                        char respfinal = Convert.ToChar(Console.ReadLine()); //En caso de querer volver a jugar
                        while (respfinal == 's')
                        {
                            goto inicio;
                        }
                        while (respfinal == 'n')
                        {
                            Environment.Exit(0); //comando para que cierre el programa
                        }
                    }
                    else
                    {
                        Console.WriteLine("No cumples la edad mínima (21 años) para jugar"); //hola mundo
                        
                    }
                    
                    Console.ReadKey();
                    Console.Clear();
                }
                catch
                {
                    Console.WriteLine("Dato no válido");
                    Console.ReadKey();
                    Console.Clear();
                }
            
            Console.ReadKey();
        }
    }
}
