﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_PABM_1109623
{
    internal class Class1
    {
    }
}
