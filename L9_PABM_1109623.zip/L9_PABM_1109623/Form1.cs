﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L9_PABM_1109623
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Automovil myAutomovil = new Automovil();
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                myAutomovil.definirPrecio(Convert.ToDouble(txtprecio.Text));
                myAutomovil.definirModelo(Convert.ToInt32(txtmodelo.Text));
                myAutomovil.definirMarca(txtmarca.Text);
                myAutomovil.definirTipoCambio(Convert.ToDouble(txtcambio.Text));

                MessageBox.Show("Se han ingresado los datos exitosamente");
                textBox2.Text = myAutomovil.MostrarInformacion();

            }
            catch
            {
                MessageBox.Show("Ha ingresado un dato inválido");
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Limpiar_Click(object sender, EventArgs e)
        {
            txtmarca.Clear();
            txtmodelo.Clear();
            txtprecio.Clear();
            txtDescuento.Clear();
            textBox2.Clear();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void bttnaplicar_Click(object sender, EventArgs e)
        {

            myAutomovil.AplicarDescuento(Convert.ToDouble(txtDescuento.Text));
            textBox2.Text = myAutomovil.MostrarInformacion();
        }

        private void bttnCambiarDisp_Click(object sender, EventArgs e)
        {
            myAutomovil.definirCambiarDisponibilidad();
             textBox2.Text = myAutomovil.MostrarInformacion();
        }
    }
}
