﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_PABM_1109623
{
    public class Automovil
    {
        private int modelo;
        private double precio, tipoCambioDolar, descuentoAplicado;
        private string marca;
        private bool disponible;

        public int Modelo { get { return modelo; } }
        public double Precio { get { return precio; } }
        public double TipoCambioDolar { get { return tipoCambioDolar; } }
        public double DescuentoAplicado { get { return descuentoAplicado; } }
        public string Marca { get { return marca; } }
        

        public Automovil()
        {
            modelo = 2019;
            precio = 10000;
            tipoCambioDolar = 7.50;
            marca = "";
            disponible = false;
            descuentoAplicado = 0;
        }
        public void definirModelo(int unModelo)
        {
            modelo= unModelo;
        }
        public void definirPrecio(double unPrecio)
        {
            precio= unPrecio;
        }
        public void definirMarca(string UnaMarca)
        {
            marca= UnaMarca;
        }
        public void definirTipoCambio (double unTipoCambio)
        {
            tipoCambioDolar = unTipoCambio;
        }
        public void definirCambiarDisponibilidad()
        {
            if (disponible)
            {
                disponible = false;
            }
            else
            {
                disponible = true;
            }
        }
        public string MostrarDisponibilidad()
        {

            if (disponible)
            {
                return "Disponible";
            }
            else
            {
                return "No se encuentra disponible actualmente";
            }
        }
        private double Conversion()
        {
            return precio / tipoCambioDolar;
        }
        public string MostrarInformacion()
        {
            return $"Marca: {marca}.\n Modelo: {modelo}.\n Precio de venta: Q{precio}.\n Precio en dolares: {Conversion()}.\n Mostrar disponibilidad: {MostrarDisponibilidad()}.";
        }
        public void AplicarDescuento(double miDescuento)
        {
            descuentoAplicado= miDescuento;
            double nuevoPrecio = precio - (descuentoAplicado);
            definirPrecio (nuevoPrecio);
        }
    }
}
